from .bsr import *
from .ocr_aadhar import *
from .ocr_dl import *
from .ocr_pan import *